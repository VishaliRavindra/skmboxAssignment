function manipulate() {
    document.getElementById("shopifyElement").style.display = "none";
    document.getElementById("advancedElement").style.display = "none";
    document.getElementById("basicElement").style.display = "block";
}

function manipulateShopify() {
    document.getElementById("shopifyElement").style.display = "block";
    document.getElementById("advancedElement").style.display = "none";
    document.getElementById("basicElement").style.display = "none";
}

function manipulateAdvanced() {
    document.getElementById("shopifyElement").style.display = "none";
    document.getElementById("advancedElement").style.display = "block";
    document.getElementById("basicElement").style.display = "none";
}

function changeColor() {
    document.getElementById("payEle").style.backgroundColor = "#000000";
    document.getElementById("payEle").style.color = "#ffffff";
    document.getElementById("payYeEle").style.backgroundColor = "transparent";
    document.getElementById("payYeEle").style.color = "#000000";

}

function changetoOriginal() {
    document.getElementById("payYeEle").style.backgroundColor = "#000000";
    document.getElementById("payYeEle").style.color = "#ffffff";
    document.getElementById("payEle").style.backgroundColor = "transparent";
    document.getElementById("payEle").style.color = "#000000";

}